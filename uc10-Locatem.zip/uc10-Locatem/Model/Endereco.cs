﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Text.Json.Serialization;
using uc10_Locatem.Enum;
using uc10_Locatem.Model;

namespace uc10_Locatem.API.Model
{
    public class Endereco
    {
        [Key]
        public int Id { get; set; }

        [Required(ErrorMessage = "Campo Obrigatorio")]
        public TipoEndereco TipoEndereco { get; set; }

        [Required(ErrorMessage = "Logradouro é um valor obrigatorio")]
        public string Logradouro { get; set; } = string.Empty;

        [Required(ErrorMessage = "Numero é um valor obrigatorio")]
        [StringLength(10)]
        public string Numero { get; set; } = string.Empty;

        [StringLength(150)]
        public string Complemento { get; set; } = string.Empty;

        [Required(ErrorMessage = "Bairro é um valor obrigatorio")]
        [StringLength(100)]
        public string Bairro { get; set; } = string.Empty;

        [Required(ErrorMessage = "Cidade é um valor obrigatorio")]
        [StringLength(100)]
        public string Cidade { get; set; } = string.Empty;

        [Required(ErrorMessage = "Estado é um valor obrigatorio")]
        [StringLength(50)]
        public string Estado { get; set; } = string.Empty;

        [Required(ErrorMessage = "CEP é um valor obrigatorio")]
        [StringLength(9)]
        public string CEP { get; set; } = string.Empty;

        public bool EhPrioritario { get; set; } = false;

        public int UsuarioId { get; set; }

        [JsonIgnore]
        [ForeignKey("UsuarioId")]
        public Usuario Usuario { get; set; } = null!;


        //para busca de ferramentas próximas

        public double? Latitude { get; set; }
        public double? Longitude { get; set; }
    }
}