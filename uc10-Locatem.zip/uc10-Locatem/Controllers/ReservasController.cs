﻿using uc10_Locatem.Data;
using Microsoft.AspNetCore.Mvc;
using uc10_Locatem.Model.DTO;
using uc10_Locatem.Enum;
using Microsoft.EntityFrameworkCore;
using uc10_Locatem.Model;
using uc10_Locatem.Services;
using Microsoft.AspNetCore.Authorization;

namespace uc10_Locatem.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class ReservasController : ControllerBase
    {
        private readonly AppDbContext _ReservaDbContext;
        private readonly ReservaService _reservaService;
        private readonly DisponibilidadeService _disponibilidadeService;

        // Injeção de dependência do ReservaService para usar a lógica de negócios relacionada às reservas
        public ReservasController(AppDbContext context, ReservaService reservaService, DisponibilidadeService disponibilidadeService)
        {
            _ReservaDbContext = context;
            _reservaService = reservaService;
            _disponibilidadeService = disponibilidadeService;
        }


        [Authorize]
        [HttpPost("criarReserva")]
        public async Task<IActionResult> CriarReserva([FromBody] CriarReservaDTO dadosReserva)
        {
            var idClaim = User.FindFirst("id")?.Value;

            if (string.IsNullOrEmpty(idClaim))
            {
                return Unauthorized("ID do usuário não encontrado no token.");
            }

            int usuarioId = int.Parse(idClaim);

            var usuarioExiste = await _ReservaDbContext.Usuario.AnyAsync(u => u.Id == usuarioId);

            if (!usuarioExiste)
            {
                return BadRequest("Usuário do token não existe no banco.");
            }

            // Verificar se a ferramenta existe

            var ferramenta = await _ReservaDbContext.Ferramenta.FindAsync(dadosReserva.FerramentaId);

            // Se a ferramenta não existir, retornar um erro 404, que o  de não encontrado.

            if (ferramenta == null)
            {
                return NotFound("Ferramenta não encontrada.");
            }

            // Impede a pessoa de reservar sua própria ferramenta

            if (ferramenta.UsuarioId == usuarioId)
            {
                return BadRequest("Não é possível reservar sua própria ferramenta.");

            }
            // Verificar se as datas são válidas (data de início deve ser anterior à data de fim)

            if (dadosReserva.DataInicio >= dadosReserva.DataFim)
            {
                return BadRequest("A data de início deve ser anterior à data de fim.");
            }

            // Verificar se a data de início não esta no passado

            if (dadosReserva.DataInicio < DateTime.UtcNow)
            {
                return BadRequest("A data de início não pode ser no passado.");
            }


            // Esta verificação foi comentada porque agora a verificação de disponibilidade é feita no serviço de disponibilidade, que pode levar em consideração outros fatores além das reservas já aceitas, como por exemplo, reservas pendentes ou regras específicas de disponibilidade para cada ferramenta. Isso torna a lógica mais flexível e centralizada, evitando duplicação de código e garantindo que todas as verificações de disponibilidade sejam consistentes em toda a aplicação.
            //// Verificar se há conflito de reservas para a mesma ferramenta no período solicitado

            //var conflito = await _ReservaDbContext.Reserva.AnyAsync(r => r.FerramentaId == dadosReserva.FerramentaId && r.Status == StatusReserva.Aceita && dadosReserva.DataInicio <= r.DataFim && dadosReserva.DataFim >= r.DataInicio
            //);

            //// Se houver conflito, retornar um erro 

            //if (conflito)
            //{
            //    return BadRequest("A ferramenta já está reservada para o período selecionado.");
            //}

            var disponibilidadeDto = new VerificarDisponibilidadeDTO
            {
                FerramentaId = dadosReserva.FerramentaId,
                DataInicio = dadosReserva.DataInicio,
                DataFim = dadosReserva.DataFim
            };

            var disponibilidade = await _disponibilidadeService.VerificarDisponibilidade(disponibilidadeDto);

            if (!disponibilidade.Disponivel)
            {
                return BadRequest(new
                {
                    Mensagem = disponibilidade.Mensagem
                });
            }

            // Serve para criar uma nova reserva com os dados fornecidos
            var reserva = new Reserva
            {
                FerramentaId = dadosReserva.FerramentaId,
                DataInicio = dadosReserva.DataInicio,
                DataFim = dadosReserva.DataFim,
                Status = StatusReserva.Pendente,
                DataCriacao = DateTime.UtcNow,
                UsuarioId = usuarioId
            };

            _ReservaDbContext.Reserva.Add(reserva);
            await _ReservaDbContext.SaveChangesAsync();

            return Ok(reserva);
        }

        [Authorize]
        [HttpPut("cancelar/{id}")]
        public async Task<IActionResult> CancelarReserva(int id)
        {
            // Aqui estou pegando o id do usuário logado para verificar se ele é o dono da reserva que está tentando cancelar
            var usuarioId = int.Parse(User.FindFirst("id").Value);

            // Chama o método CancelarReserva do services de reservas, passando o id da reserva e o id do usuário logado
            var (sucesso, mensagem) = await _reservaService.CancelarReserva(id, usuarioId);

            // Se o cancelamento não for bem-sucedido, retorna um erro 400 com a mensagem de erro
            if (!sucesso)
                return BadRequest(mensagem);

            // Se o cancelamento for bem-sucedido, retorna um status 200 com a mensagem de sucesso
            return Ok(mensagem);

        }

        [Authorize]
        [HttpPut("aceitar/{id}")]
        public async Task<IActionResult> AceitarReserva(int id)
        {
            var usuarioIdClaim = User.FindFirst("id")?.Value;

            if (usuarioIdClaim == null)
            {
                return Unauthorized("Usuário não autenticado.");
            }

            int usuarioId = int.Parse(usuarioIdClaim);

            var (sucesso, mensagem) = await _reservaService.AceitarReserva(id, usuarioId);

            if (!sucesso)
            {
                return BadRequest(new { Mensagem = mensagem });
            }

            return Ok(new { Mensagem = mensagem });
        }

        [Authorize]
        [HttpPut("recusar/{reservaId}")]
        public async Task<IActionResult> RecusarReserva(int id)
        {
            // Aqui estou pegando o id do usuário logado para verificar se ele é o dono da ferramenta relacionada à reserva que está tentando recusar
            var usuarioId = int.Parse(User.FindFirst("id").Value);
            // Chama o método RecusarReserva do serviço de reservas, passando o id da reserva e o id do usuário logado
            var (sucesso, mensagem) = await _reservaService.RecusarReserva(id, usuarioId);
            // Se a recusa não for bem-sucedida, retorna um erro 400 com a mensagem de erro
            if (!sucesso)
                return BadRequest(mensagem);
            // Se a recusa for bem-sucedida, retorna um status 200 com a mensagem de sucesso
            return Ok(mensagem);
        }

        [Authorize]
        [HttpGet("minhasReservas")]
        public async Task<IActionResult> MinhasReservas()
        {
            // Aqui estou pegando o id do usuário logado para buscar as reservas relacionadas a ele
            var usuarioId = int.Parse(User.FindFirst("id").Value);

            // Chama o método ListarReservasDoUsuario do service de reservas, passando o id do usuário logado para obter a lista de reservas relacionadas a ele
            var reservas = await _reservaService.ListarReservasDoUsuario(usuarioId);

            // Retorna a lista de reservas do usuário logado
            return Ok(reservas);
        }

        [Authorize]
        [HttpGet("reservasRecebidas")]
        public async Task<IActionResult> ReservasRecebidas()
        {
            // Aqui estou pegando o id do usuário logado para buscar as reservas relacionadas às ferramentas que ele possui
            var usuarioId = int.Parse(User.FindFirst("id").Value);
            // Chama o método ListarReservasRecebidas do service de reservas, passando o id do usuário logado para obter a lista de reservas relacionadas às ferramentas que ele possui
            var reservas = await _reservaService.ListarResrvasRecebidas(usuarioId);
            // Retorna a lista de reservas recebidas para as ferramentas do usuário logado
            return Ok(reservas);
        }
    }
}
